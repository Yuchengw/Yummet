package com.yummet.mongodb.entities;

import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "RequestPosts")
public class DBRequestPost extends DBPostObject {

	private static final long serialVersionUID = -6011241820070393945L;  

	@Override
	public String getDbTableName() {
		return "RequestPosts";
	}

	public DBRequestPost(String id) {
		setId(id);
	}

	public DBRequestPost() {
		super();
	}
}
