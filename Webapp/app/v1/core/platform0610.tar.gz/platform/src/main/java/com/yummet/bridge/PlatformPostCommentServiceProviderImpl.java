package com.yummet.bridge;

public class PlatformPostCommentServiceProviderImpl implements PlatformServiceProvider {

}
