package com.yummet.bridge;


/**
 * @author yucheng
 * @since 1
 * */
public interface PlatformServiceProvider {
}
