package com.yummet.entities;

import com.yummet.mongodb.entities.DBPostObject;
import com.yummet.mongodb.entities.DBRequestPost;

public class RequestPostObject extends PostObject {
	private static final long serialVersionUID = -6011241820070393925L;  
	public RequestPostObject(String id) {
		super(id);
	}
	
	@Override
	public Class<?> getDbClass() {
		return DBRequestPost.class;
	}

	@Override
	public String getDbTableName() {
		return new DBRequestPost().getDbTableName();
	}

	@Override
	public DBPostObject getBasicDBObject() {
		DBRequestPost post = new DBRequestPost();
		return post;
	}
}
