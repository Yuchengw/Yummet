package com.yummet.mongodb.entities;

import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "ProvidePosts")
public class DBProvidePost extends DBPostObject {
	/**
	 * 
	 */
	private static final long serialVersionUID = -6011241820070393935L;  

	@Override
	public String getDbTableName() {
		return "ProvidePosts";
	}
	
	public DBProvidePost(String id) {
		setId(id);
	}

	public DBProvidePost() {
		super();
	}
}
