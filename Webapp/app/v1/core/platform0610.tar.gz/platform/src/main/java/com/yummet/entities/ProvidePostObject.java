package com.yummet.entities;

import com.yummet.mongodb.entities.DBPostObject;
import com.yummet.mongodb.entities.DBProvidePost;

public class ProvidePostObject extends PostObject {
	private static final long serialVersionUID = -6011241820070393915L;  
	
	public ProvidePostObject(String id) {
		super(id);
	}
	
	@Override
	public Class<?> getDbClass() {
		return DBProvidePost.class;
	}

	@Override
	public String getDbTableName() {
		return new DBProvidePost().getDbTableName();
	}

	@Override
	public DBPostObject getBasicDBObject() {
		DBProvidePost post = new DBProvidePost();
		return post;
	}
}
